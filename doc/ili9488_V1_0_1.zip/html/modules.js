var modules =
[
    [ "ILI9488_API", "group___i_l_i9488___a_p_i.html", "group___i_l_i9488___a_p_i" ],
    [ "ILI9488_DRIVER", "group___i_l_i9488___d_r_i_v_e_r.html", "group___i_l_i9488___d_r_i_v_e_r" ],
    [ "APP_LOW", "group___a_p_p___l_o_w.html", "group___a_p_p___l_o_w" ],
    [ "ILI9488_LOW_IF", "group___i_l_i9488___l_o_w___i_f.html", "group___i_l_i9488___l_o_w___i_f" ],
    [ "FONTS", "group___f_o_n_t_s.html", "group___f_o_n_t_s" ],
    [ "LOW_LEVEL_IF", "group___l_o_w___l_e_v_e_l___i_f.html", "group___l_o_w___l_e_v_e_l___i_f" ],
    [ "ILI9488_REGDEF", "group___i_l_i9488___r_e_g_d_e_f.html", "group___i_l_i9488___r_e_g_d_e_f" ]
];