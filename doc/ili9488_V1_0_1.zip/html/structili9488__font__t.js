var structili9488__font__t =
[
    [ "height", "structili9488__font__t.html#a42654a49e8d4708af90b7e13e01b61e7", null ],
    [ "p_font", "structili9488__font__t.html#a47684975a912350a3d647b1b2c71d8b2", null ],
    [ "width", "structili9488__font__t.html#a409af8326e11bbb8e2c30396e9f21ed6", null ]
];