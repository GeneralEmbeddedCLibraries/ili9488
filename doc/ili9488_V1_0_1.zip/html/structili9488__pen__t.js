var structili9488__pen__t =
[
    [ "bg_color", "structili9488__pen__t.html#a70052f462b3acb552d14f153cf3c4b04", null ],
    [ "fg_color", "structili9488__pen__t.html#a30c07d99ed18c32bd60b801c18472419", null ],
    [ "font_opt", "structili9488__pen__t.html#acef2bae3153fa5fcf7f087bd54cabfa3", null ]
];