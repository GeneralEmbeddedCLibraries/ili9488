var group___i_l_i9488___a_p_i =
[
    [ "ili9488_pen_t", "structili9488__pen__t.html", [
      [ "bg_color", "structili9488__pen__t.html#a70052f462b3acb552d14f153cf3c4b04", null ],
      [ "fg_color", "structili9488__pen__t.html#a30c07d99ed18c32bd60b801c18472419", null ],
      [ "font_opt", "structili9488__pen__t.html#acef2bae3153fa5fcf7f087bd54cabfa3", null ]
    ] ],
    [ "ili9488_cursor_t", "structili9488__cursor__t.html", [
      [ "col", "structili9488__cursor__t.html#a628ca12d0ca0c09f0321380fee0a1c5e", null ],
      [ "page", "structili9488__cursor__t.html#af36f4242c9fc748959e27a91c33fda78", null ]
    ] ],
    [ "ili9488_rect_attr_t", "structili9488__rect__attr__t.html", [
      [ "border", "structili9488__rect__attr__t.html#a789a8886199ecda9ad29a0ab8b6366a4", null ],
      [ "col_size", "structili9488__rect__attr__t.html#a596a9b946d2fef882c391e2688a960d4", null ],
      [ "color", "structili9488__rect__attr__t.html#aa05abdb89b388185ef523d95ccc75c82", null ],
      [ "enable", "structili9488__rect__attr__t.html#a197e2d25a1fed5905e1b75037fbf04e2", null ],
      [ "fill", "structili9488__rect__attr__t.html#a766659d1768f8aebca4238b2df39f61b", null ],
      [ "page_size", "structili9488__rect__attr__t.html#a2c9cdbb58a1d20860a99b8840c08b34c", null ],
      [ "position", "structili9488__rect__attr__t.html#a8ca6865203e67818c0ffc1e1c6dba54d", null ],
      [ "radius", "structili9488__rect__attr__t.html#ae7d9e217a85126eeb51c53d969ef36d4", null ],
      [ "rounded", "structili9488__rect__attr__t.html#a6b4097cf81d4e4e99f0cd1deb1165587", null ],
      [ "start_col", "structili9488__rect__attr__t.html#a55f7104b0f96be575b1acd12011dd03d", null ],
      [ "start_page", "structili9488__rect__attr__t.html#a9fe21aa5f17e2182cd5eda4f03a11d78", null ],
      [ "width", "structili9488__rect__attr__t.html#af5f1c746d2fbd22a7a8034b73b6c6455", null ]
    ] ],
    [ "ili9488_circ_attr_t", "structili9488__circ__attr__t.html", [
      [ "border", "structili9488__circ__attr__t.html#a9e92b8c67af9ae96f3ef4c83014bd112", null ],
      [ "color", "structili9488__circ__attr__t.html#ac27864647b6ca768372b8c36ef361b8e", null ],
      [ "enable", "structili9488__circ__attr__t.html#aea567f38c10fbc9da759f402bda2d723", null ],
      [ "fill", "structili9488__circ__attr__t.html#a5890e95093474b2dd3f45b2124ca1757", null ],
      [ "position", "structili9488__circ__attr__t.html#ae2b67d625949d25bd0af45a7c12a8189", null ],
      [ "radius", "structili9488__circ__attr__t.html#a63c489afb4c81ae3f75b57dfd8927d3e", null ],
      [ "start_col", "structili9488__circ__attr__t.html#a6da2814d8c993b4c6198b3014f784b83", null ],
      [ "start_page", "structili9488__circ__attr__t.html#ab37be3aa829ae5846e8bf415f27951b7", null ],
      [ "width", "structili9488__circ__attr__t.html#a7c80fd71740cba22d0907fed6f6d34ec", null ]
    ] ],
    [ "ILI9488_VER_DEVELOP", "group___i_l_i9488___a_p_i.html#ga226f95ca47bf2544489dc530c62fbd4d", null ],
    [ "ILI9488_VER_MAJOR", "group___i_l_i9488___a_p_i.html#ga40dcdfd57e4a2ffaa4e5638d04f53c2d", null ],
    [ "ILI9488_VER_MINOR", "group___i_l_i9488___a_p_i.html#ga64ad43de04ab9720242eff2271fc91d6", null ],
    [ "ili9488_color_t", "group___i_l_i9488___a_p_i.html#gac506ee7dda49aca306de0921a17e9c69", [
      [ "eILI9488_COLOR_BLACK", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69ab7f79a8ec9c59275425a6bdcb57f8717", null ],
      [ "eILI9488_COLOR_BLUE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69aed5da1182de1821ed082738ef6f4bfd7", null ],
      [ "eILI9488_COLOR_GREEN", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69af043652a31c11c84c4402fa3e3939b4e", null ],
      [ "eILI9488_COLOR_TURQUOISE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69af590a256e1012f9432f44455f9bb69ae", null ],
      [ "eILI9488_COLOR_RED", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69aa741b3b1cf6c0806b89db610b1cd57a1", null ],
      [ "eILI9488_COLOR_PURPLE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69aa3fdc59e219fd49d547917750d8715ab", null ],
      [ "eILI9488_COLOR_YELLOW", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69af2520d67fb7cd02eaae3379172c91a3f", null ],
      [ "eILI9488_COLOR_WHITE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69a27768c36074735718118dfaac7820ecd", null ],
      [ "eILI9488_COLOR_LIGHT_GRAY", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69ab7c36b6eaf12704b842a802beb4c7ae0", null ],
      [ "eILI9488_COLOR_GRAY", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69ace10562e602ca6b4732f85d590ac73a7", null ]
    ] ],
    [ "ili9488_font_opt_t", "group___i_l_i9488___a_p_i.html#gaef600fffc077d4e3fe166417fdadeacc", [
      [ "eILI9488_FONT_8", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca779edc790b6a8c2123604cf085cbd25d", null ],
      [ "eILI9488_FONT_12", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca1f1c5cbbda361bba7327a9be1b4dc88a", null ],
      [ "eILI9488_FONT_16", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca2210b34b7ba3ac695a958294ac66bd6f", null ],
      [ "eILI9488_FONT_20", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeaccac0e7bdd208014c0f561f87fd917a8d7c", null ],
      [ "eILI9488_FONT_24", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca9748e0890c604dd159c244fa8f266d2b", null ],
      [ "eILI9488_FONT_NUM_OF", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeaccaa15c303234e40280683a9585f52d90e3", null ]
    ] ],
    [ "ili9488_status_t", "group___i_l_i9488___a_p_i.html#gaf4c9a056e85ba3d519e69eb7f3e9f24d", [
      [ "eILI9488_OK", "group___i_l_i9488___a_p_i.html#ggaf4c9a056e85ba3d519e69eb7f3e9f24daf17fa3adad0e841f9a7699e2141a69c3", null ],
      [ "eILI9488_ERROR", "group___i_l_i9488___a_p_i.html#ggaf4c9a056e85ba3d519e69eb7f3e9f24daa973892bd4e45628313ca82c312afc0e", null ],
      [ "eILI9488_ERROR_SPI", "group___i_l_i9488___a_p_i.html#ggaf4c9a056e85ba3d519e69eb7f3e9f24dab5e3ee0e5a489f73be849f2fb42a49ed", null ]
    ] ],
    [ "ili9488_draw_circle", "group___i_l_i9488___a_p_i.html#gabc7ae56945dea87bc5f718c462071835", null ],
    [ "ili9488_draw_rectangle", "group___i_l_i9488___a_p_i.html#ga3e36a1c2925938e12bd5c08138461b94", null ],
    [ "ili9488_fill_circle", "group___i_l_i9488___a_p_i.html#gad6a9902e7e8ddfa05e4e5dfa1947643c", null ],
    [ "ili9488_fill_rectangle", "group___i_l_i9488___a_p_i.html#ga5ca38ff14cd732ff3fbcc1c0e57877a2", null ],
    [ "ili9488_fill_round_rectangle", "group___i_l_i9488___a_p_i.html#ga0b6d183830755cf9297d8dbe53e8f02f", null ],
    [ "ili9488_get_cursor", "group___i_l_i9488___a_p_i.html#ga50d7407642b41152b51b133607ebec86", null ],
    [ "ili9488_get_font_height", "group___i_l_i9488___a_p_i.html#gae6c6f19cca53b66d33671ec7dd864722", null ],
    [ "ili9488_get_font_width", "group___i_l_i9488___a_p_i.html#gaa94e2d2d70214aa35bfa07f6ef2e0686", null ],
    [ "ili9488_init", "group___i_l_i9488___a_p_i.html#ga348e1c016839f58328bbab28e5c7c701", null ],
    [ "ili9488_is_init", "group___i_l_i9488___a_p_i.html#gace6915f0cb219e8f2c9af01f884b94f8", null ],
    [ "ili9488_printf", "group___i_l_i9488___a_p_i.html#ga2e55bae2f445370489ba747f8f8cbf19", null ],
    [ "ili9488_set_background", "group___i_l_i9488___a_p_i.html#ga920daea6f62bec5d68a7eff70faea03a", null ],
    [ "ili9488_set_backlight", "group___i_l_i9488___a_p_i.html#gafedf5057796765b4c64359aabb82bc38", null ],
    [ "ili9488_set_cursor", "group___i_l_i9488___a_p_i.html#ga0fd6b539b867659782b2a2a807addd05", null ],
    [ "ili9488_set_string", "group___i_l_i9488___a_p_i.html#gadedf788ad3d697304af52203dd400293", null ],
    [ "ili9488_set_string_pen", "group___i_l_i9488___a_p_i.html#gadefb2dff24da77ffb52953df406fc6e3", null ],
    [ "g_stringCursor", "group___i_l_i9488___a_p_i.html#gab78dd5d668f6ee3a9a635b5126fe8d8e", null ],
    [ "g_stringPen", "group___i_l_i9488___a_p_i.html#ga22ac5850c4ae498d21571871c8cd68b7", null ],
    [ "gb_is_init", "group___i_l_i9488___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ]
];