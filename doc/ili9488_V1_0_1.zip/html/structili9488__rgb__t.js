var structili9488__rgb__t =
[
    [ "B", "structili9488__rgb__t.html#a0dc98ee02aa2c30c892421d8ce641f41", null ],
    [ "G", "structili9488__rgb__t.html#abc994da075597414f8c20e5b04173ceb", null ],
    [ "R", "structili9488__rgb__t.html#a809ffa30b1d1c62fa1e16c6768268310", null ]
];