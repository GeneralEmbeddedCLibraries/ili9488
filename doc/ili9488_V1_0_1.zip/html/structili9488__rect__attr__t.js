var structili9488__rect__attr__t =
[
    [ "border", "structili9488__rect__attr__t.html#a789a8886199ecda9ad29a0ab8b6366a4", null ],
    [ "col_size", "structili9488__rect__attr__t.html#a596a9b946d2fef882c391e2688a960d4", null ],
    [ "color", "structili9488__rect__attr__t.html#aa05abdb89b388185ef523d95ccc75c82", null ],
    [ "enable", "structili9488__rect__attr__t.html#a197e2d25a1fed5905e1b75037fbf04e2", null ],
    [ "fill", "structili9488__rect__attr__t.html#a766659d1768f8aebca4238b2df39f61b", null ],
    [ "page_size", "structili9488__rect__attr__t.html#a2c9cdbb58a1d20860a99b8840c08b34c", null ],
    [ "position", "structili9488__rect__attr__t.html#a8ca6865203e67818c0ffc1e1c6dba54d", null ],
    [ "radius", "structili9488__rect__attr__t.html#ae7d9e217a85126eeb51c53d969ef36d4", null ],
    [ "rounded", "structili9488__rect__attr__t.html#a6b4097cf81d4e4e99f0cd1deb1165587", null ],
    [ "start_col", "structili9488__rect__attr__t.html#a55f7104b0f96be575b1acd12011dd03d", null ],
    [ "start_page", "structili9488__rect__attr__t.html#a9fe21aa5f17e2182cd5eda4f03a11d78", null ],
    [ "width", "structili9488__rect__attr__t.html#af5f1c746d2fbd22a7a8034b73b6c6455", null ]
];