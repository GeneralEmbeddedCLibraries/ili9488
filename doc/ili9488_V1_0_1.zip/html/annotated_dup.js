var annotated_dup =
[
    [ "ili9488_circ_attr_t", "structili9488__circ__attr__t.html", "structili9488__circ__attr__t" ],
    [ "ili9488_cursor_t", "structili9488__cursor__t.html", "structili9488__cursor__t" ],
    [ "ili9488_font_t", "structili9488__font__t.html", "structili9488__font__t" ],
    [ "ili9488_pen_t", "structili9488__pen__t.html", "structili9488__pen__t" ],
    [ "ili9488_rect_attr_t", "structili9488__rect__attr__t.html", "structili9488__rect__attr__t" ],
    [ "ili9488_rgb_t", "structili9488__rgb__t.html", "structili9488__rgb__t" ]
];