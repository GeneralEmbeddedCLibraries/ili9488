var structili9488__circ__attr__t =
[
    [ "border", "structili9488__circ__attr__t.html#a9e92b8c67af9ae96f3ef4c83014bd112", null ],
    [ "color", "structili9488__circ__attr__t.html#ac27864647b6ca768372b8c36ef361b8e", null ],
    [ "enable", "structili9488__circ__attr__t.html#aea567f38c10fbc9da759f402bda2d723", null ],
    [ "fill", "structili9488__circ__attr__t.html#a5890e95093474b2dd3f45b2124ca1757", null ],
    [ "position", "structili9488__circ__attr__t.html#ae2b67d625949d25bd0af45a7c12a8189", null ],
    [ "radius", "structili9488__circ__attr__t.html#a63c489afb4c81ae3f75b57dfd8927d3e", null ],
    [ "start_col", "structili9488__circ__attr__t.html#a6da2814d8c993b4c6198b3014f784b83", null ],
    [ "start_page", "structili9488__circ__attr__t.html#ab37be3aa829ae5846e8bf415f27951b7", null ],
    [ "width", "structili9488__circ__attr__t.html#a7c80fd71740cba22d0907fed6f6d34ec", null ]
];