var searchData=
[
  ['col_4',['col',['../structili9488__cursor__t.html#a628ca12d0ca0c09f0321380fee0a1c5e',1,'ili9488_cursor_t']]],
  ['col_5fsize_5',['col_size',['../structili9488__rect__attr__t.html#a596a9b946d2fef882c391e2688a960d4',1,'ili9488_rect_attr_t']]],
  ['color_6',['color',['../structili9488__rect__attr__t.html#aa05abdb89b388185ef523d95ccc75c82',1,'ili9488_rect_attr_t::color()'],['../structili9488__circ__attr__t.html#ac27864647b6ca768372b8c36ef361b8e',1,'ili9488_circ_attr_t::color()']]]
];
