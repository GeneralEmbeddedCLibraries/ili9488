var searchData=
[
  ['r_319',['R',['../structili9488__rgb__t.html#a809ffa30b1d1c62fa1e16c6768268310',1,'ili9488_rgb_t']]],
  ['radius_320',['radius',['../structili9488__rect__attr__t.html#ae7d9e217a85126eeb51c53d969ef36d4',1,'ili9488_rect_attr_t::radius()'],['../structili9488__circ__attr__t.html#a63c489afb4c81ae3f75b57dfd8927d3e',1,'ili9488_circ_attr_t::radius()']]],
  ['rounded_321',['rounded',['../structili9488__rect__attr__t.html#a6b4097cf81d4e4e99f0cd1deb1165587',1,'ili9488_rect_attr_t']]]
];
