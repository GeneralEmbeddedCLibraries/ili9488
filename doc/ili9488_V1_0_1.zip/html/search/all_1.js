var searchData=
[
  ['b_1',['B',['../structili9488__rgb__t.html#a0dc98ee02aa2c30c892421d8ce641f41',1,'ili9488_rgb_t']]],
  ['bg_5fcolor_2',['bg_color',['../structili9488__pen__t.html#a70052f462b3acb552d14f153cf3c4b04',1,'ili9488_pen_t']]],
  ['border_3',['border',['../structili9488__rect__attr__t.html#a789a8886199ecda9ad29a0ab8b6366a4',1,'ili9488_rect_attr_t::border()'],['../structili9488__circ__attr__t.html#a9e92b8c67af9ae96f3ef4c83014bd112',1,'ili9488_circ_attr_t::border()']]]
];
