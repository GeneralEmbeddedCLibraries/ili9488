var searchData=
[
  ['start_5fcol_322',['start_col',['../structili9488__rect__attr__t.html#a55f7104b0f96be575b1acd12011dd03d',1,'ili9488_rect_attr_t::start_col()'],['../structili9488__circ__attr__t.html#a6da2814d8c993b4c6198b3014f784b83',1,'ili9488_circ_attr_t::start_col()']]],
  ['start_5fpage_323',['start_page',['../structili9488__rect__attr__t.html#a9fe21aa5f17e2182cd5eda4f03a11d78',1,'ili9488_rect_attr_t::start_page()'],['../structili9488__circ__attr__t.html#ab37be3aa829ae5846e8bf415f27951b7',1,'ili9488_circ_attr_t::start_page()']]]
];
