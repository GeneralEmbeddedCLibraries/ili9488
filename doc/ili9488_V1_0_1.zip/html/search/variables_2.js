var searchData=
[
  ['enable_300',['enable',['../structili9488__rect__attr__t.html#a197e2d25a1fed5905e1b75037fbf04e2',1,'ili9488_rect_attr_t::enable()'],['../structili9488__circ__attr__t.html#aea567f38c10fbc9da759f402bda2d723',1,'ili9488_circ_attr_t::enable()']]]
];
