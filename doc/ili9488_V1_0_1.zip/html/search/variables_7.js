var searchData=
[
  ['p_5ffont_315',['p_font',['../structili9488__font__t.html#a47684975a912350a3d647b1b2c71d8b2',1,'ili9488_font_t']]],
  ['page_316',['page',['../structili9488__cursor__t.html#af36f4242c9fc748959e27a91c33fda78',1,'ili9488_cursor_t']]],
  ['page_5fsize_317',['page_size',['../structili9488__rect__attr__t.html#a2c9cdbb58a1d20860a99b8840c08b34c',1,'ili9488_rect_attr_t']]],
  ['position_318',['position',['../structili9488__rect__attr__t.html#a8ca6865203e67818c0ffc1e1c6dba54d',1,'ili9488_rect_attr_t::position()'],['../structili9488__circ__attr__t.html#ae2b67d625949d25bd0af45a7c12a8189',1,'ili9488_circ_attr_t::position()']]]
];
