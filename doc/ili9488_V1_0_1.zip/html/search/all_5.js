var searchData=
[
  ['g_106',['G',['../structili9488__rgb__t.html#abc994da075597414f8c20e5b04173ceb',1,'ili9488_rgb_t']]],
  ['g_5ffontlist_107',['g_fontList',['../group___f_o_n_t_s.html#ga364416d5789bcdcd4eb60ce7e8683748',1,'ili9488_font.c']]],
  ['g_5fstringcursor_108',['g_stringCursor',['../group___i_l_i9488___a_p_i.html#gab78dd5d668f6ee3a9a635b5126fe8d8e',1,'ili9488.c']]],
  ['g_5fstringpen_109',['g_stringPen',['../group___i_l_i9488___a_p_i.html#ga22ac5850c4ae498d21571871c8cd68b7',1,'ili9488.c']]],
  ['gb_5fis_5finit_110',['gb_is_init',['../group___i_l_i9488___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385',1,'ili9488.c']]]
];
