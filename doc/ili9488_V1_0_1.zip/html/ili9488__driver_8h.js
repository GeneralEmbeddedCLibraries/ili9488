var ili9488__driver_8h =
[
    [ "ili9488_all_pixels_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga1d69173350c57aef26dded37540fa016", [
      [ "eILI9488_ALL_PIXELS_OFF", "group___i_l_i9488___d_r_i_v_e_r.html#gga1d69173350c57aef26dded37540fa016a2d695fb42c6be5e00d21038f390de697", null ],
      [ "eILI9488_ALL_PIXELS_ON", "group___i_l_i9488___d_r_i_v_e_r.html#gga1d69173350c57aef26dded37540fa016a40e6290a2199f3d3c07a2ec72c9c4cf0", null ]
    ] ],
    [ "ili9488_display_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga0407160879bf387cea0c779f5e7b8c32", [
      [ "eILI9488_DISPLAY_OFF", "group___i_l_i9488___d_r_i_v_e_r.html#gga0407160879bf387cea0c779f5e7b8c32abc441a429f0167f586a5defe3ae2bf22", null ],
      [ "eILI9488_DISPLAY_ON", "group___i_l_i9488___d_r_i_v_e_r.html#gga0407160879bf387cea0c779f5e7b8c32a437b2014dcb5319394e443c407f25aaa", null ]
    ] ],
    [ "ili9488_idle_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga58b3de9c2399b24871f51392078beb80", [
      [ "eILI9488_IDLE_OFF", "group___i_l_i9488___d_r_i_v_e_r.html#gga58b3de9c2399b24871f51392078beb80acd793a8e668c7e6cf97a3117da449ab1", null ],
      [ "eILI9488_IDLE_ON", "group___i_l_i9488___d_r_i_v_e_r.html#gga58b3de9c2399b24871f51392078beb80aec89185f54c41d33786c9e3e3da5ffc6", null ]
    ] ],
    [ "ili9488_inversion_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga0586c9849bfc31997a3e4957f1d6e749", [
      [ "eILI9488_DISPLAY_INVERSION_OFF", "group___i_l_i9488___d_r_i_v_e_r.html#gga0586c9849bfc31997a3e4957f1d6e749adc3f7775a65df42ca0506e28f70f679a", null ],
      [ "eILI9488_DISPLAY_INVERSION_ON", "group___i_l_i9488___d_r_i_v_e_r.html#gga0586c9849bfc31997a3e4957f1d6e749a51a81c23469b2ac5de8e874515d18e49", null ]
    ] ],
    [ "ili9488_madctl_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga8974dcc003097b061eef1b06f0053b01", [
      [ "eILI9488_MADCTL_NORMAL", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01aa11e4a72e6cd33f7a41d087fd40c0b51", null ],
      [ "eILI9488_MADCTL_Y_MIRROR", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01adfcb27503933ed1380b9ddac224622ba", null ],
      [ "eILI9488_MADCTL_X_MIRROR", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01ada795f3524b3a8de882cb1beb474348e", null ],
      [ "eILI9488_MADCTL_XY_MIRROR", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01a75dea207d1103fbf20be4b4ac098fe24", null ],
      [ "eILI9488_MADCTL_XY_EXCHANGE", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01a6fd82547eda9d4b51b275f7e77c5e870", null ],
      [ "eILI9488_MADCTL_XY_EXCHANGE_Y_MIRROR", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01a36d5b9dae6c5fb22505d4a83988230e3", null ],
      [ "eILI9488_MADCTL_XY_EXCHANGE_X_MIRROR", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01ad3a2ec22ed57ff395baee10adcd9965b", null ],
      [ "eILI9488_MADCTL_XY_EXCHANGE_XY_MIRROR", "group___i_l_i9488___d_r_i_v_e_r.html#gga8974dcc003097b061eef1b06f0053b01ab717bcb5dd7f3e1c97eed37fc97d2bf6", null ]
    ] ],
    [ "ili9488_mode_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga3f78d3276f0a3ab8a1dcd83cf7c97aa6", [
      [ "eILI9488_MODE_NORMAL", "group___i_l_i9488___d_r_i_v_e_r.html#gga3f78d3276f0a3ab8a1dcd83cf7c97aa6a113df05b6fd95cb895fdeeda15ae580b", null ],
      [ "eILI9488_MODE_PARTIAL", "group___i_l_i9488___d_r_i_v_e_r.html#gga3f78d3276f0a3ab8a1dcd83cf7c97aa6a73562140616df440547e54296ddb63fb", null ]
    ] ],
    [ "ili9488_orientation_t", "group___i_l_i9488___d_r_i_v_e_r.html#gae09b43994e7aae25ea1a868b0d778d2a", [
      [ "eILI9488_ORIENTATION_LANDSCAPE", "group___i_l_i9488___d_r_i_v_e_r.html#ggae09b43994e7aae25ea1a868b0d778d2aa3312683d2fefe2a79278ea19b0500fd3", null ],
      [ "eILI9488_ORIENTATION_LANDSCAPE_FLIP", "group___i_l_i9488___d_r_i_v_e_r.html#ggae09b43994e7aae25ea1a868b0d778d2aab89521efc751c11990c12d7afa6c88c8", null ]
    ] ],
    [ "ili9488_pixel_format_t", "group___i_l_i9488___d_r_i_v_e_r.html#gafbadf0b98e7eadaf8f4c1db0f3217ba7", [
      [ "eILI9488_PIXEL_FORMAT_3_BIT", "group___i_l_i9488___d_r_i_v_e_r.html#ggafbadf0b98e7eadaf8f4c1db0f3217ba7aa0c9f34b4dfa08e648d81b293b3c5887", null ],
      [ "eILI9488_PIXEL_FORMAT_16_BIT", "group___i_l_i9488___d_r_i_v_e_r.html#ggafbadf0b98e7eadaf8f4c1db0f3217ba7a04cb286e9ed190cf31a119ffe04f57c9", null ],
      [ "eILI9488_PIXEL_FORMAT_18_BIT", "group___i_l_i9488___d_r_i_v_e_r.html#ggafbadf0b98e7eadaf8f4c1db0f3217ba7a62f5246073035034992add753b6561f4", null ],
      [ "eILI9488_PIXEL_FORMAT_24_BIT", "group___i_l_i9488___d_r_i_v_e_r.html#ggafbadf0b98e7eadaf8f4c1db0f3217ba7a8282ed4f09caa395138603f23887670d", null ]
    ] ],
    [ "ili9488_sleep_t", "group___i_l_i9488___d_r_i_v_e_r.html#ga5fe3371203acbc721516f614c6d5135a", [
      [ "eILI9488_SLEEP_OFF", "group___i_l_i9488___d_r_i_v_e_r.html#gga5fe3371203acbc721516f614c6d5135aa026ace5176876420da2492cb896cb208", null ],
      [ "eILI9488_SLEEP_ON", "group___i_l_i9488___d_r_i_v_e_r.html#gga5fe3371203acbc721516f614c6d5135aa5c63fded67ab4493d1bc55b6941c17fd", null ]
    ] ],
    [ "ili9488_driver_fill_circle", "group___i_l_i9488___d_r_i_v_e_r.html#ga0de45682f5d7260bc767f94dfc2cea79", null ],
    [ "ili9488_driver_fill_rectangle", "group___i_l_i9488___d_r_i_v_e_r.html#ga180fb029f3bfabc93e0bcd91fb672e3a", null ],
    [ "ili9488_driver_get_orientation", "group___i_l_i9488___d_r_i_v_e_r.html#ga1d5eadf022823d26475d8d6c88801408", null ],
    [ "ili9488_driver_init", "group___i_l_i9488___d_r_i_v_e_r.html#gafe381b4304e424d843e6b3927a88552c", null ],
    [ "ili9488_driver_read_brightness_control", "group___i_l_i9488___d_r_i_v_e_r.html#ga5700e0eba72fb8b1e8370f6448d66d53", null ],
    [ "ili9488_driver_read_memory", "group___i_l_i9488___d_r_i_v_e_r.html#gadd77838a4b84a2ce0a17c34e7bbe93d2", null ],
    [ "ili9488_driver_read_pixel_format", "group___i_l_i9488___d_r_i_v_e_r.html#ga2e893fb172d15c8c825fc85609b3021a", null ],
    [ "ili9488_driver_set_all_pixels", "group___i_l_i9488___d_r_i_v_e_r.html#gada702e24d631259d18f8cbad15b1de89", null ],
    [ "ili9488_driver_set_brightness_control", "group___i_l_i9488___d_r_i_v_e_r.html#ga3c43f8f509bbeee10b7f64ad77c5ecac", null ],
    [ "ili9488_driver_set_char", "group___i_l_i9488___d_r_i_v_e_r.html#ga475ddd7407fb1f8e4ffd0a3f7a9fc215", null ],
    [ "ili9488_driver_set_circle", "group___i_l_i9488___d_r_i_v_e_r.html#ga9b946eb42111d16be2210e8db60f947d", null ],
    [ "ili9488_driver_set_cursor", "group___i_l_i9488___d_r_i_v_e_r.html#ga7049e2a04e8c4ef4b8848b46878ffcbd", null ],
    [ "ili9488_driver_set_display_inversion", "group___i_l_i9488___d_r_i_v_e_r.html#gaf85e81dd19cd806ceffcf76111fd1f4f", null ],
    [ "ili9488_driver_set_display_on_off", "group___i_l_i9488___d_r_i_v_e_r.html#ga3f46305d38c40f324c96a17a0d19d79f", null ],
    [ "ili9488_driver_set_idle_on_off", "group___i_l_i9488___d_r_i_v_e_r.html#ga56d3a0c5a78d0d788f0ba22ef1cbafdf", null ],
    [ "ili9488_driver_set_mode", "group___i_l_i9488___d_r_i_v_e_r.html#gaa3aeedffee51d49c3d3cd092bb9b2799", null ],
    [ "ili9488_driver_set_orientation", "group___i_l_i9488___d_r_i_v_e_r.html#ga31b05b894b631d293b189f486717407a", null ],
    [ "ili9488_driver_set_pixel", "group___i_l_i9488___d_r_i_v_e_r.html#gac63987596f01900fecac3b0e247c8eb6", null ],
    [ "ili9488_driver_set_pixel_format", "group___i_l_i9488___d_r_i_v_e_r.html#gacd65ad5ca877fc5761f9b77c34983d10", null ],
    [ "ili9488_driver_set_sleep_on_off", "group___i_l_i9488___d_r_i_v_e_r.html#gaa732a687cfdec483202e00bd2ed46c3f", null ],
    [ "ili9488_driver_set_string", "group___i_l_i9488___d_r_i_v_e_r.html#ga0ab3c006d7fc328ec461ccd7515f163c", null ],
    [ "ili9488_driver_soft_reset", "group___i_l_i9488___d_r_i_v_e_r.html#gaeb22161cc2a5c998c0d356bb68304c19", null ],
    [ "ili9488_driver_write_memory", "group___i_l_i9488___d_r_i_v_e_r.html#ga75904b254ba4d30bf556efef670c1f87", null ]
];