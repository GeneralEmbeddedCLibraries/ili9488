var group___i_l_i9488___l_o_w___i_f =
[
    [ "ili9488_rgb_t", "structili9488__rgb__t.html", [
      [ "B", "structili9488__rgb__t.html#a0dc98ee02aa2c30c892421d8ce641f41", null ],
      [ "G", "structili9488__rgb__t.html#abc994da075597414f8c20e5b04173ceb", null ],
      [ "R", "structili9488__rgb__t.html#a809ffa30b1d1c62fa1e16c6768268310", null ]
    ] ],
    [ "ili9488_low_if_read_register", "group___i_l_i9488___l_o_w___i_f.html#ga5ae1c6b45611aff84ac032c8983cf9cd", null ],
    [ "ili9488_low_if_write_register", "group___i_l_i9488___l_o_w___i_f.html#gaf9df776525ab546de1c6388eec587b9b", null ],
    [ "ili9488_low_if_write_rgb_to_gram", "group___i_l_i9488___l_o_w___i_f.html#ga3f394b1c721a0e55ab32ad4de8a9b9dd", null ]
];