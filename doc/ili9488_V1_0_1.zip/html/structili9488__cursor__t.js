var structili9488__cursor__t =
[
    [ "col", "structili9488__cursor__t.html#a628ca12d0ca0c09f0321380fee0a1c5e", null ],
    [ "page", "structili9488__cursor__t.html#af36f4242c9fc748959e27a91c33fda78", null ]
];