var ili9488_8c =
[
    [ "ili9488_draw_circle", "group___i_l_i9488___a_p_i.html#gabc7ae56945dea87bc5f718c462071835", null ],
    [ "ili9488_draw_rectangle", "group___i_l_i9488___a_p_i.html#ga3e36a1c2925938e12bd5c08138461b94", null ],
    [ "ili9488_fill_circle", "group___i_l_i9488___a_p_i.html#gad6a9902e7e8ddfa05e4e5dfa1947643c", null ],
    [ "ili9488_fill_rectangle", "group___i_l_i9488___a_p_i.html#ga5ca38ff14cd732ff3fbcc1c0e57877a2", null ],
    [ "ili9488_fill_round_rectangle", "group___i_l_i9488___a_p_i.html#ga0b6d183830755cf9297d8dbe53e8f02f", null ],
    [ "ili9488_init", "group___i_l_i9488___a_p_i.html#ga348e1c016839f58328bbab28e5c7c701", null ],
    [ "ili9488_is_init", "group___i_l_i9488___a_p_i.html#gace6915f0cb219e8f2c9af01f884b94f8", null ],
    [ "ili9488_printf", "group___i_l_i9488___a_p_i.html#ga2e55bae2f445370489ba747f8f8cbf19", null ],
    [ "ili9488_set_background", "group___i_l_i9488___a_p_i.html#ga920daea6f62bec5d68a7eff70faea03a", null ],
    [ "ili9488_set_backlight", "group___i_l_i9488___a_p_i.html#gafedf5057796765b4c64359aabb82bc38", null ],
    [ "ili9488_set_cursor", "group___i_l_i9488___a_p_i.html#ga0fd6b539b867659782b2a2a807addd05", null ],
    [ "ili9488_set_string", "group___i_l_i9488___a_p_i.html#gadedf788ad3d697304af52203dd400293", null ],
    [ "ili9488_set_string_pen", "group___i_l_i9488___a_p_i.html#gadefb2dff24da77ffb52953df406fc6e3", null ],
    [ "g_stringCursor", "group___i_l_i9488___a_p_i.html#gab78dd5d668f6ee3a9a635b5126fe8d8e", null ],
    [ "g_stringPen", "group___i_l_i9488___a_p_i.html#ga22ac5850c4ae498d21571871c8cd68b7", null ],
    [ "gb_is_init", "group___i_l_i9488___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ]
];