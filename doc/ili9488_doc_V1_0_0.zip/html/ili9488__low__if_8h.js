var ili9488__low__if_8h =
[
    [ "ili9488_low_if_read_register", "group___i_l_i9488___l_o_w___i_f.html#ga5ae1c6b45611aff84ac032c8983cf9cd", null ],
    [ "ili9488_low_if_write_register", "group___i_l_i9488___l_o_w___i_f.html#gaf9df776525ab546de1c6388eec587b9b", null ],
    [ "ili9488_low_if_write_rgb_to_gram", "group___i_l_i9488___l_o_w___i_f.html#ga3f394b1c721a0e55ab32ad4de8a9b9dd", null ]
];