var structili9488__rect__attr__t =
[
    [ "border", "group___i_l_i9488___a_p_i.html#ga789a8886199ecda9ad29a0ab8b6366a4", null ],
    [ "col_size", "group___i_l_i9488___a_p_i.html#ga596a9b946d2fef882c391e2688a960d4", null ],
    [ "color", "group___i_l_i9488___a_p_i.html#gaa05abdb89b388185ef523d95ccc75c82", null ],
    [ "enable", "group___i_l_i9488___a_p_i.html#ga197e2d25a1fed5905e1b75037fbf04e2", null ],
    [ "fill", "group___i_l_i9488___a_p_i.html#ga766659d1768f8aebca4238b2df39f61b", null ],
    [ "page_size", "group___i_l_i9488___a_p_i.html#ga2c9cdbb58a1d20860a99b8840c08b34c", null ],
    [ "position", "group___i_l_i9488___a_p_i.html#ga8ca6865203e67818c0ffc1e1c6dba54d", null ],
    [ "radius", "group___i_l_i9488___a_p_i.html#gae7d9e217a85126eeb51c53d969ef36d4", null ],
    [ "rounded", "group___i_l_i9488___a_p_i.html#ga6b4097cf81d4e4e99f0cd1deb1165587", null ],
    [ "start_col", "group___i_l_i9488___a_p_i.html#ga55f7104b0f96be575b1acd12011dd03d", null ],
    [ "start_page", "group___i_l_i9488___a_p_i.html#ga9fe21aa5f17e2182cd5eda4f03a11d78", null ],
    [ "width", "group___i_l_i9488___a_p_i.html#gaf5f1c746d2fbd22a7a8034b73b6c6455", null ]
];