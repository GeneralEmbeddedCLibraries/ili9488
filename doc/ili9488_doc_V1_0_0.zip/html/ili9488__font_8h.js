var ili9488__font_8h =
[
    [ "ili9488_font_get", "group___a_p_p___l_o_w.html#gad561381aed6bd40d3a14d69cdb83a502", null ],
    [ "ili9488_font_get_height", "group___a_p_p___l_o_w.html#gaf99137223761059d8329a150c1b3e564", null ],
    [ "ili9488_font_get_width", "group___a_p_p___l_o_w.html#ga6dd5b4b56dbce22dd1fdd832ed5a7582", null ]
];