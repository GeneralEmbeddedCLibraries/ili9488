var group___l_o_w___l_e_v_e_l___i_f =
[
    [ "ILI9488_LOW_IF_CS_HIGH", "group___l_o_w___l_e_v_e_l___i_f.html#ga393aa2faf58873cc542618968b0b27f4", null ],
    [ "ILI9488_LOW_IF_CS_LOW", "group___l_o_w___l_e_v_e_l___i_f.html#gae5c70cc4133f4f0f88d5206abe13da02", null ],
    [ "ILI9488_LOW_IF_DC_COMMAND", "group___l_o_w___l_e_v_e_l___i_f.html#gae0b8157051c6f79b71374c85b281d750", null ],
    [ "ILI9488_LOW_IF_DC_DATA", "group___l_o_w___l_e_v_e_l___i_f.html#ga840b24d127fa1f02a194542dbf2ccb26", null ],
    [ "ili9488_low_if_read_register", "group___l_o_w___l_e_v_e_l___i_f.html#ga5ae1c6b45611aff84ac032c8983cf9cd", null ],
    [ "ili9488_low_if_write_register", "group___l_o_w___l_e_v_e_l___i_f.html#gaf9df776525ab546de1c6388eec587b9b", null ],
    [ "ili9488_low_if_write_rgb_to_gram", "group___l_o_w___l_e_v_e_l___i_f.html#ga3f394b1c721a0e55ab32ad4de8a9b9dd", null ]
];