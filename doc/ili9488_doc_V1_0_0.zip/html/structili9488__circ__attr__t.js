var structili9488__circ__attr__t =
[
    [ "border", "group___i_l_i9488___a_p_i.html#ga9e92b8c67af9ae96f3ef4c83014bd112", null ],
    [ "color", "group___i_l_i9488___a_p_i.html#gac27864647b6ca768372b8c36ef361b8e", null ],
    [ "enable", "group___i_l_i9488___a_p_i.html#gaea567f38c10fbc9da759f402bda2d723", null ],
    [ "fill", "group___i_l_i9488___a_p_i.html#ga5890e95093474b2dd3f45b2124ca1757", null ],
    [ "position", "group___i_l_i9488___a_p_i.html#gae2b67d625949d25bd0af45a7c12a8189", null ],
    [ "radius", "group___i_l_i9488___a_p_i.html#ga63c489afb4c81ae3f75b57dfd8927d3e", null ],
    [ "start_col", "group___i_l_i9488___a_p_i.html#ga6da2814d8c993b4c6198b3014f784b83", null ],
    [ "start_page", "group___i_l_i9488___a_p_i.html#gab37be3aa829ae5846e8bf415f27951b7", null ],
    [ "width", "group___i_l_i9488___a_p_i.html#ga7c80fd71740cba22d0907fed6f6d34ec", null ]
];