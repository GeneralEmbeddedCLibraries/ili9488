var ili9488_8h =
[
    [ "ili9488_color_t", "group___i_l_i9488___a_p_i.html#gac506ee7dda49aca306de0921a17e9c69", [
      [ "eILI9488_COLOR_BLACK", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69ab7f79a8ec9c59275425a6bdcb57f8717", null ],
      [ "eILI9488_COLOR_BLUE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69aed5da1182de1821ed082738ef6f4bfd7", null ],
      [ "eILI9488_COLOR_GREEN", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69af043652a31c11c84c4402fa3e3939b4e", null ],
      [ "eILI9488_COLOR_TURQUOISE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69af590a256e1012f9432f44455f9bb69ae", null ],
      [ "eILI9488_COLOR_RED", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69aa741b3b1cf6c0806b89db610b1cd57a1", null ],
      [ "eILI9488_COLOR_PURPLE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69aa3fdc59e219fd49d547917750d8715ab", null ],
      [ "eILI9488_COLOR_YELLOW", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69af2520d67fb7cd02eaae3379172c91a3f", null ],
      [ "eILI9488_COLOR_WHITE", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69a27768c36074735718118dfaac7820ecd", null ],
      [ "eILI9488_COLOR_LIGHT_GRAY", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69ab7c36b6eaf12704b842a802beb4c7ae0", null ],
      [ "eILI9488_COLOR_GRAY", "group___i_l_i9488___a_p_i.html#ggac506ee7dda49aca306de0921a17e9c69ace10562e602ca6b4732f85d590ac73a7", null ]
    ] ],
    [ "ili9488_font_opt_t", "group___i_l_i9488___a_p_i.html#gaef600fffc077d4e3fe166417fdadeacc", [
      [ "eILI9488_FONT_8", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca779edc790b6a8c2123604cf085cbd25d", null ],
      [ "eILI9488_FONT_12", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca1f1c5cbbda361bba7327a9be1b4dc88a", null ],
      [ "eILI9488_FONT_16", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca2210b34b7ba3ac695a958294ac66bd6f", null ],
      [ "eILI9488_FONT_20", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeaccac0e7bdd208014c0f561f87fd917a8d7c", null ],
      [ "eILI9488_FONT_24", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeacca9748e0890c604dd159c244fa8f266d2b", null ],
      [ "eILI9488_FONT_NUM_OF", "group___i_l_i9488___a_p_i.html#ggaef600fffc077d4e3fe166417fdadeaccaa15c303234e40280683a9585f52d90e3", null ]
    ] ],
    [ "ili9488_status_t", "group___i_l_i9488___a_p_i.html#gaf4c9a056e85ba3d519e69eb7f3e9f24d", [
      [ "eILI9488_OK", "group___i_l_i9488___a_p_i.html#ggaf4c9a056e85ba3d519e69eb7f3e9f24daf17fa3adad0e841f9a7699e2141a69c3", null ],
      [ "eILI9488_ERROR", "group___i_l_i9488___a_p_i.html#ggaf4c9a056e85ba3d519e69eb7f3e9f24daa973892bd4e45628313ca82c312afc0e", null ],
      [ "eILI9488_ERROR_SPI", "group___i_l_i9488___a_p_i.html#ggaf4c9a056e85ba3d519e69eb7f3e9f24dab5e3ee0e5a489f73be849f2fb42a49ed", null ]
    ] ],
    [ "ili9488_draw_circle", "group___i_l_i9488___a_p_i.html#gabc7ae56945dea87bc5f718c462071835", null ],
    [ "ili9488_draw_rectangle", "group___i_l_i9488___a_p_i.html#ga3e36a1c2925938e12bd5c08138461b94", null ],
    [ "ili9488_init", "group___i_l_i9488___a_p_i.html#ga348e1c016839f58328bbab28e5c7c701", null ],
    [ "ili9488_is_init", "group___i_l_i9488___a_p_i.html#gace6915f0cb219e8f2c9af01f884b94f8", null ],
    [ "ili9488_printf", "group___i_l_i9488___a_p_i.html#ga2e55bae2f445370489ba747f8f8cbf19", null ],
    [ "ili9488_set_background", "group___i_l_i9488___a_p_i.html#ga920daea6f62bec5d68a7eff70faea03a", null ],
    [ "ili9488_set_backlight", "group___i_l_i9488___a_p_i.html#gafedf5057796765b4c64359aabb82bc38", null ],
    [ "ili9488_set_cursor", "group___i_l_i9488___a_p_i.html#ga0fd6b539b867659782b2a2a807addd05", null ],
    [ "ili9488_set_string", "group___i_l_i9488___a_p_i.html#gadedf788ad3d697304af52203dd400293", null ],
    [ "ili9488_set_string_pen", "group___i_l_i9488___a_p_i.html#gadefb2dff24da77ffb52953df406fc6e3", null ]
];