var group___f_o_n_t_s =
[
    [ "ili9488_font_get", "group___f_o_n_t_s.html#gad561381aed6bd40d3a14d69cdb83a502", null ],
    [ "ili9488_font_get_height", "group___f_o_n_t_s.html#gaf99137223761059d8329a150c1b3e564", null ],
    [ "ili9488_font_get_width", "group___f_o_n_t_s.html#ga6dd5b4b56dbce22dd1fdd832ed5a7582", null ],
    [ "g_fontList", "group___f_o_n_t_s.html#ga364416d5789bcdcd4eb60ce7e8683748", null ],
    [ "ili9488_font12_lut", "group___f_o_n_t_s.html#ga46e0767739da6a79dcfdf78758676789", null ],
    [ "ili9488_font16_lut", "group___f_o_n_t_s.html#ga4c17b0be7003fa3e36c3b5b06a2d4c03", null ],
    [ "ili9488_font20_lut", "group___f_o_n_t_s.html#ga03fc2a00e92402c8e62c3cea3a120caa", null ],
    [ "ili9488_font24_lut", "group___f_o_n_t_s.html#gad000644d70b200ee75be5af3e8c295ac", null ],
    [ "ili9488_font8_lut", "group___f_o_n_t_s.html#gaaf5d4637b87dec35223b8d8bed371fe4", null ]
];