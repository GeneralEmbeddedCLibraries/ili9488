var searchData=
[
  ['b_285',['B',['../group___i_l_i9488___l_o_w___i_f.html#ga0dc98ee02aa2c30c892421d8ce641f41',1,'ili9488_rgb_t']]],
  ['bg_5fcolor_286',['bg_color',['../structili9488__pen__t.html#a70052f462b3acb552d14f153cf3c4b04',1,'ili9488_pen_t']]],
  ['border_287',['border',['../group___i_l_i9488___a_p_i.html#ga789a8886199ecda9ad29a0ab8b6366a4',1,'ili9488_rect_attr_t::border()'],['../group___i_l_i9488___a_p_i.html#ga9e92b8c67af9ae96f3ef4c83014bd112',1,'ili9488_circ_attr_t::border()']]]
];
