var searchData=
[
  ['width_315',['width',['../group___i_l_i9488___a_p_i.html#gaf5f1c746d2fbd22a7a8034b73b6c6455',1,'ili9488_rect_attr_t::width()'],['../group___i_l_i9488___a_p_i.html#ga071bff3eae1f6250adc416be2b35c16e',1,'ili9488_rect_attr_t::@3::width()'],['../group___i_l_i9488___a_p_i.html#ga7c80fd71740cba22d0907fed6f6d34ec',1,'ili9488_circ_attr_t::width()'],['../group___i_l_i9488___a_p_i.html#ga8955b8fdc96af094d746e5ec6256bdac',1,'ili9488_circ_attr_t::@6::width()'],['../group___a_p_p___l_o_w.html#ga409af8326e11bbb8e2c30396e9f21ed6',1,'ili9488_font_t::width()']]]
];
