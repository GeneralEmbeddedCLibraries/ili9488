var searchData=
[
  ['p_5ffont_306',['p_font',['../group___a_p_p___l_o_w.html#ga47684975a912350a3d647b1b2c71d8b2',1,'ili9488_font_t']]],
  ['page_307',['page',['../structili9488__cursor__t.html#af36f4242c9fc748959e27a91c33fda78',1,'ili9488_cursor_t']]],
  ['page_5fsize_308',['page_size',['../group___i_l_i9488___a_p_i.html#ga2c9cdbb58a1d20860a99b8840c08b34c',1,'ili9488_rect_attr_t::page_size()'],['../group___i_l_i9488___a_p_i.html#gafdc0a19ee11f46e0f1639a8028b619f7',1,'ili9488_rect_attr_t::@0::page_size()']]],
  ['position_309',['position',['../group___i_l_i9488___a_p_i.html#ga8ca6865203e67818c0ffc1e1c6dba54d',1,'ili9488_rect_attr_t::position()'],['../group___i_l_i9488___a_p_i.html#gae2b67d625949d25bd0af45a7c12a8189',1,'ili9488_circ_attr_t::position()']]]
];
