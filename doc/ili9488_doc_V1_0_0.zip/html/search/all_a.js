var searchData=
[
  ['r_212',['R',['../group___i_l_i9488___l_o_w___i_f.html#ga809ffa30b1d1c62fa1e16c6768268310',1,'ili9488_rgb_t']]],
  ['radius_213',['radius',['../group___i_l_i9488___a_p_i.html#gae7d9e217a85126eeb51c53d969ef36d4',1,'ili9488_rect_attr_t::radius()'],['../group___i_l_i9488___a_p_i.html#ga909f522a1256ba4f3b6b59782fcbd613',1,'ili9488_rect_attr_t::@1::radius()'],['../group___i_l_i9488___a_p_i.html#ga63c489afb4c81ae3f75b57dfd8927d3e',1,'ili9488_circ_attr_t::radius()'],['../group___i_l_i9488___a_p_i.html#gadfc14c5da703b01aa4481a4f82992fce',1,'ili9488_circ_attr_t::@4::radius()']]],
  ['rounded_214',['rounded',['../group___i_l_i9488___a_p_i.html#ga6b4097cf81d4e4e99f0cd1deb1165587',1,'ili9488_rect_attr_t']]]
];
