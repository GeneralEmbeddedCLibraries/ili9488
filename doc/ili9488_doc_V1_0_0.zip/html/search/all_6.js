var searchData=
[
  ['height_111',['height',['../group___a_p_p___l_o_w.html#ga42654a49e8d4708af90b7e13e01b61e7',1,'ili9488_font_t']]]
];
