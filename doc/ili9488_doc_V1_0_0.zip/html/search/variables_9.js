var searchData=
[
  ['start_5fcol_313',['start_col',['../group___i_l_i9488___a_p_i.html#ga55f7104b0f96be575b1acd12011dd03d',1,'ili9488_rect_attr_t::start_col()'],['../group___i_l_i9488___a_p_i.html#ga316eef3a02ec2bfe08cf40b7f8d13ef7',1,'ili9488_rect_attr_t::@0::start_col()'],['../group___i_l_i9488___a_p_i.html#ga6da2814d8c993b4c6198b3014f784b83',1,'ili9488_circ_attr_t::start_col()'],['../group___i_l_i9488___a_p_i.html#gace3f36a65930742d20bfa7932dfe84ed',1,'ili9488_circ_attr_t::@4::start_col()']]],
  ['start_5fpage_314',['start_page',['../group___i_l_i9488___a_p_i.html#ga9fe21aa5f17e2182cd5eda4f03a11d78',1,'ili9488_rect_attr_t::start_page()'],['../group___i_l_i9488___a_p_i.html#ga476f5ad8cf9345f8293f4cbe9638710b',1,'ili9488_rect_attr_t::@0::start_page()'],['../group___i_l_i9488___a_p_i.html#gab37be3aa829ae5846e8bf415f27951b7',1,'ili9488_circ_attr_t::start_page()'],['../group___i_l_i9488___a_p_i.html#gafb0a739f19ebc0a961a84340ec8496ba',1,'ili9488_circ_attr_t::@4::start_page()']]]
];
