var searchData=
[
  ['col_4',['col',['../structili9488__cursor__t.html#a628ca12d0ca0c09f0321380fee0a1c5e',1,'ili9488_cursor_t']]],
  ['col_5fsize_5',['col_size',['../group___i_l_i9488___a_p_i.html#ga596a9b946d2fef882c391e2688a960d4',1,'ili9488_rect_attr_t::col_size()'],['../group___i_l_i9488___a_p_i.html#ga6cf35eda1dc12e1e01628323cc2458bd',1,'ili9488_rect_attr_t::@0::col_size()']]],
  ['color_6',['color',['../group___i_l_i9488___a_p_i.html#gaa05abdb89b388185ef523d95ccc75c82',1,'ili9488_rect_attr_t::color()'],['../group___i_l_i9488___a_p_i.html#ga849200a8337b9c1636239dd2645f4480',1,'ili9488_rect_attr_t::@2::color()'],['../group___i_l_i9488___a_p_i.html#gad51f0cbd1005689d7f0b52ba563ca066',1,'ili9488_rect_attr_t::@3::color()'],['../group___i_l_i9488___a_p_i.html#gac27864647b6ca768372b8c36ef361b8e',1,'ili9488_circ_attr_t::color()'],['../group___i_l_i9488___a_p_i.html#gaab32c5fbbfcea02f33ce224e643c837b',1,'ili9488_circ_attr_t::@5::color()'],['../group___i_l_i9488___a_p_i.html#gaea491c234fb2d206393498ea0edb814a',1,'ili9488_circ_attr_t::@6::color()']]]
];
