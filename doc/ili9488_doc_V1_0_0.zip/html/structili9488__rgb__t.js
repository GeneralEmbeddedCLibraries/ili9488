var structili9488__rgb__t =
[
    [ "B", "group___i_l_i9488___l_o_w___i_f.html#ga0dc98ee02aa2c30c892421d8ce641f41", null ],
    [ "G", "group___i_l_i9488___l_o_w___i_f.html#gabc994da075597414f8c20e5b04173ceb", null ],
    [ "R", "group___i_l_i9488___l_o_w___i_f.html#ga809ffa30b1d1c62fa1e16c6768268310", null ]
];