var structili9488__font__t =
[
    [ "height", "group___a_p_p___l_o_w.html#ga42654a49e8d4708af90b7e13e01b61e7", null ],
    [ "p_font", "group___a_p_p___l_o_w.html#ga47684975a912350a3d647b1b2c71d8b2", null ],
    [ "width", "group___a_p_p___l_o_w.html#ga409af8326e11bbb8e2c30396e9f21ed6", null ]
];